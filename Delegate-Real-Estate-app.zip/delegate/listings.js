/* Delegate Real Estate — property listings.
   Edit this file to add, change or remove properties.
   deal:  "sale" or "rent"  (rent price is per month, in USD)
   type:  "Apartment", "Villa", "Land" or "Commercial"
   sample: true marks a demonstration listing. Remove that line on real ones. */
window.DELEGATE_LISTINGS = [
  { id: "DR-101", sample: true, featured: true, deal: "sale", type: "Apartment", area: "Majdalyoun",
    title: "Sea-view apartment with terrace", price: 185000, beds: 3, baths: 3, size: 210,
    desc: "Bright corner apartment on a quiet street in Majdalyoun, with an open reception, a wide terrace facing the sea and two parking spaces.",
    features: ["Sea view", "2 parking spaces", "Terrace", "Generator", "Green title deed"] },
  { id: "DR-102", sample: true, featured: true, deal: "sale", type: "Villa", area: "Abra",
    title: "Stone villa with garden", price: 620000, beds: 5, baths: 5, size: 480,
    desc: "Detached two-storey villa in natural stone, set in a landscaped garden with a covered seating area and a private entrance.",
    features: ["Private garden", "Fireplace", "Maid's room", "Solar system", "Covered parking"] },
  { id: "DR-103", sample: true, featured: true, deal: "rent", type: "Apartment", area: "Sidon",
    title: "Furnished apartment near the Corniche", price: 750, beds: 2, baths: 2, size: 135,
    desc: "Fully furnished two-bedroom apartment a short walk from the Sidon seafront, ready to move in.",
    features: ["Furnished", "Elevator", "24/7 electricity", "Balcony"] },
  { id: "DR-104", sample: true, deal: "sale", type: "Land", area: "Maghdouche",
    title: "Residential plot with open view", price: 240000, beds: 0, baths: 0, size: 1150,
    desc: "Gently sloping plot zoned for residential building, with road access and an open view toward the coast.",
    features: ["Road access", "Open view", "Residential zoning"] },
  { id: "DR-105", sample: true, deal: "rent", type: "Commercial", area: "Sidon",
    title: "Street-front shop on a main road", price: 1400, beds: 0, baths: 1, size: 95,
    desc: "Ground-floor shop with a wide glass frontage on a busy commercial street, suitable for retail or a showroom.",
    features: ["Glass frontage", "Mezzanine", "High footfall"] },
  { id: "DR-106", sample: true, deal: "sale", type: "Apartment", area: "Hlaliyeh",
    title: "New-build apartment, first occupancy", price: 142000, beds: 3, baths: 2, size: 165,
    desc: "Never-lived-in apartment in a recently completed building, with quality finishes and a private storage room.",
    features: ["New building", "Storage room", "Parking", "Elevator"] },
  { id: "DR-107", sample: true, deal: "rent", type: "Villa", area: "Bramieh",
    title: "Family villa with pool", price: 2800, beds: 4, baths: 4, size: 390,
    desc: "Spacious family villa in a calm residential area, with a private pool, a garden and a large living area.",
    features: ["Private pool", "Garden", "Central heating", "3 parking spaces"] },
  { id: "DR-108", sample: true, deal: "sale", type: "Commercial", area: "Ghazieh",
    title: "Office floor in a business centre", price: 310000, beds: 0, baths: 2, size: 260,
    desc: "Open-plan office floor with a reception, a meeting room and dedicated visitor parking.",
    features: ["Open plan", "Meeting room", "Visitor parking", "Elevator"] },
  { id: "DR-109", sample: true, deal: "sale", type: "Land", area: "Majdalyoun",
    title: "Hillside plot near the village centre", price: 175000, beds: 0, baths: 0, size: 820,
    desc: "Corner plot within walking distance of the village centre, bordered by two roads.",
    features: ["Corner plot", "Two road frontages", "Utilities nearby"] }
];
